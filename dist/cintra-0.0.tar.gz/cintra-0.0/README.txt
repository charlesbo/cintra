cintra README
